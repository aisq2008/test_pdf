#ifndef EXAMPLE_HPP  
#define EXAMPLE_HPP  

int MAC(int a, int b, int& sum);

#endif // !EXAMPLE_HPP  