#include "Example.hpp"

int MAC(int a, int b, int& sum)
{
    sum += a*b;
    return sum;
}
