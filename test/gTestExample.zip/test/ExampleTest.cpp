#include "Example.hpp" //想要包含Example.hpp 头文件，需注意目录结构

#include <gtest/gtest.h> 

// 要继承Test这个类，override关键字表示覆盖了基类中的方法
struct Foo: public ::testing::Test
{
    //测试环境初始化
    virtual void SetUp() override
    {
        a = 0;
        printf("hello\n"); 
    }

    //测试环境清理
    virtual void TearDown() override
    {
        printf("world\n");
    }

    int a;
};


// 全局变量
int sideEffect = 42;

// 有副作用的函数: 修改了全局变量真的值
bool f()
{
    sideEffect = 16; 
    return true;    // try false  
}

//创建一个测试用例。第一个参数是测试集的名称；第二个参数是测试用例的名称，该测试用例属于第一个参数所指定的测试集。这两个名称都必须是合法的C++标识符，并且不应该包含下划线(_)。
TEST(ExampleTest, DemonstrateGtestMacros)
{
    const bool result = f(); 
    
    EXPECT_EQ(true, result) << "hello aaa"; //打印附加输出，只在失败时才输出
    ASSERT_TRUE(true);

}

TEST(ExampleTests, MAC)
{
    int x = 42; int y = 16;
    int sum = 100; int oldSum = sum; 
    int expectedNewSum = oldSum + x*y ;


    EXPECT_EQ(
        expectedNewSum,
        MAC(x, y, sum)
    );

    EXPECT_EQ(
        expectedNewSum,
        sum
    );
}

TEST(test1, testAssert)
{
   
   EXPECT_TRUE(true);
}


TEST_F(Foo, IsZeroInitially) {
    EXPECT_EQ(a, 0);
}
